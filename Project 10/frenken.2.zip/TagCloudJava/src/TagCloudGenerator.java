import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Program to take a file of text, count each instance of every word, and
 * generate a tag cloud with each word and corresponding size
 *
 * @author Robert Frenken
 * @author Bennett Palmer
 *
 *         NOTE: This code handles all words to lower case
 */
public final class TagCloudGenerator {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private TagCloudGenerator() {
        // no code needed here
    }

    /**
     * Compare {@code String}s in alphabetical order.
     */

    private static class StringLT
            implements Comparator<Map.Entry<String, Integer>> {
        @Override
        public int compare(Map.Entry<String, Integer> o1,
                Map.Entry<String, Integer> o2) {
            // use to lower case to group both capitalized and non capitalized
            String o1String = o1.getKey().toLowerCase();
            String o2String = o2.getKey().toLowerCase();

            int returnNumber = o1String.compareTo(o2String);
            if (returnNumber == 0) {
                int num = o2.getValue().compareTo(o1.getValue());
                if (num > 0) {
                    returnNumber = 1;
                } else if (num < 0) {
                    returnNumber = -1;
                }
                // otherwise they are the same, return zero
            }
            return returnNumber;
        }
    }

    /**
     * Compare {@code Integer}i in decreasing order.
     */
    private static class IntegerLT
            implements Comparator<Map.Entry<String, Integer>> {
        @Override
        public int compare(Map.Entry<String, Integer> o1,
                Map.Entry<String, Integer> o2) {
            // use to lower case to group both capitalized and non capitalized
            String o1String = o1.getKey().toLowerCase();
            String o2String = o2.getKey().toLowerCase();

            int returnNumber = o2.getValue().compareTo(o1.getValue());
            if (returnNumber == 0) {
                // use string to break the "tie"
                returnNumber = o1String.compareTo(o2String);
            }
            return returnNumber;
        }
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violations of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (!strSet.contains(c)) {
                strSet.add(c);
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        int endPosition = position;
        boolean type = separators.contains(text.charAt(position));
        boolean typeChange = type;

        // keeps going until end of line or the type of character changes from the first character
        while (type == typeChange && endPosition < text.length()) {
            typeChange = separators.contains(text.charAt(endPosition));
            endPosition++;
        }

        // correct for the extra count in the while loop
        if (type != typeChange) {
            endPosition--;
        }

        return text.substring(position, endPosition);
    }

    /**
     * Take file given and build a map, with each word to lower case as the map
     * key and the occurrence of each word as the map value.
     *
     * @param in
     *            the SimpleReader file
     * @ensures all words from inFile will be in map, with count of each word
     * @return Map<String, Integer> of words of the file and their counts
     */
    private static Map<String, Integer> readFileToMap(BufferedReader inFile) {
        assert inFile != null : "Violation of: inFile is not null";

        Map<String, Integer> map = new HashMap<String, Integer>();

        /*
         * Define separator characters for test
         */
        final String separatorStr = " \t, .-!?_@#$%&*[]();:";
        Set<Character> separatorSet = new HashSet<>();
        generateElements(separatorStr, separatorSet);
        try {
            String oneLine = inFile.readLine();
            // Read file, and compile all the words into map
            while (oneLine != null) {

                int i = 0;
                while (i < oneLine.length()) {
                    String word = nextWordOrSeparator(oneLine, i, separatorSet)
                            .toLowerCase();
                    boolean isWord = true;
                    char c = word.charAt(0);
                    if (separatorSet.contains(c)) {
                        isWord = false;
                    }

                    if (isWord) {
                        // add word to map or add one to count
                        if (map.containsKey(word)) {
                            int count = map.get(word);
                            map.replace(word, count + 1);
                        } else {
                            map.put(word, 1);
                        }
                    }
                    i += word.length();
                }
                oneLine = inFile.readLine();
            }
        } catch (IOException e) {
            System.err.print("error reading from file");
        }

        return map;

    }

    /**
     * Takes map and integer value, and first sorts the map with sortingMachine
     * by occurrence of each word in decreasing order. Then makes a second
     * sortingMachine, and sorts alphabetically. numberDisplay determines the
     * number of words to be put in second sortingMachine.
     *
     * @param map
     *            map of all of the words and their counts
     * @param numberDisplay
     *            the amount of words that will be in the first sortingMachine
     * @requires map is not null
     * @ensures all Map.Pairs is sorted in decreasing order by their values
     * @return SortingMachine<Map.Pair<String, Integer>> of words and their
     *         counts in alphabetical order
     *
     */
    public static List<Map.Entry<String, Integer>> mapToListAlphabet(
            Map<String, Integer> map, int numberDisplay) {
        assert map != null : "Violation of: words is not null";

        Comparator<Map.Entry<String, Integer>> sortByCount = new IntegerLT();
        Comparator<Map.Entry<String, Integer>> sortByAlpha = new StringLT();

        List<Map.Entry<String, Integer>> list = new ArrayList<>();
        list.addAll(map.entrySet());
        Collections.sort(list, sortByCount);

        // create the smaller list
        List<Map.Entry<String, Integer>> listAlpha = list.subList(0,
                numberDisplay);
        Collections.sort(listAlpha, sortByAlpha);

        return listAlpha;
    }

    /**
     * Outputs the tag cloud given the words in SortingMachie
     *
     * @param sortAlpha
     *            the map sorted alphabetically
     * @param out
     *            the output stream
     * @param title
     *            the string of the file name
     * @updates out.content
     * @requires out.is_open
     * @ensures out.content = #out.content * [the HTML tags]
     */
    private static void outputhtml(List<Map.Entry<String, Integer>> sortAlpha,
            PrintWriter out, String title) {

        out.println("<html>");
        out.println("<head>");
        out.println("<title>" + title
                + "</title><link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">"
                + "</head><body><h2>" + "Top " + sortAlpha.size() + " words in "
                + title + "</h2><hr>");

        out.println("<div class=\"cdiv\">");
        out.println("<p class =" + '"' + "cbox" + '"' + ">");
        int maxCount = 0;
        for (Map.Entry<String, Integer> p : sortAlpha) {
            if (p.getValue() > maxCount) {
                maxCount = p.getValue();
            }
        }

        while (sortAlpha.size() > 0) {
            // removes "smallest"
            Map.Entry<String, Integer> temp = sortAlpha.remove(0);

            int fontSize = 37 * temp.getValue() / maxCount + 11;
            out.println("<span style=\"cursor:default\" class=\"f" + fontSize
                    + "\" title=\"count:" + temp.getValue() + "\">"
                    + temp.getKey() + "</span>");
        }
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);

        System.out.print("Enter file that will be used to obtain the words: ");
        String textFile = keyboard.nextLine();
        BufferedReader inFile;
        try {
            inFile = new BufferedReader(new FileReader(textFile));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.err.print("error opening file");
            return;
        }

        System.out.print("Enter the name of a of the html page to write to: ");
        String htmlpage = keyboard.nextLine();
        PrintWriter outputhtml;
        try {
            outputhtml = new PrintWriter(
                    new BufferedWriter(new FileWriter(htmlpage)));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.err.print("error opening file");

            return;
        }

        System.out.print(
                "Enter the number of words that will be displayed (integer): ");
        String numberToDisplay = keyboard.nextLine();
        // checks if number is positive integer
        int numberDisplay = 0;
        try {
            numberDisplay = Integer.parseInt(numberToDisplay);
        } catch (NumberFormatException e) {
            System.err.print("not an int. Need to enter an integer");
        }

        Map<String, Integer> map = readFileToMap(inFile);
        List<Map.Entry<String, Integer>> list = mapToListAlphabet(map,
                numberDisplay);
        outputhtml(list, outputhtml, textFile);

        try {
            inFile.close();
            outputhtml.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.err.print("error closing file");
        }
        keyboard.close();
    }

}
