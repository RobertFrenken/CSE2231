import components.map.Map;
import components.program.Program;
import components.program.Program1;
import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.utilities.Reporter;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary method {@code parse} for {@code Program}.
 *
 * @author Robert Frenken
 * @author Bennett Palmer
 *
 */
public final class Program1Parse1 extends Program1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Parses a single BL instruction from {@code tokens} returning the
     * instruction name as the value of the function and the body of the
     * instruction in {@code body}.
     *
     * @param tokens
     *            the input tokens
     * @param body
     *            the instruction body
     * @return the instruction name
     * @replaces body
     * @updates tokens
     * @requires <pre>
     * [<"INSTRUCTION"> is a prefix of tokens]  and
     *  [<Tokenizer.END_OF_INPUT> is a suffix of tokens]
     * </pre>
     * @ensures <pre>
     * if [an instruction string is a proper prefix of #tokens]  and
     *    [the beginning name of this instruction equals its ending name]  and
     *    [the name of this instruction does not equal the name of a primitive
     *     instruction in the BL language] then
     *  parseInstruction = [name of instruction at start of #tokens]  and
     *  body = [Statement corresponding to statement string of body of
     *          instruction at start of #tokens]  and
     *  #tokens = [instruction string at start of #tokens] * tokens
     * else
     *  [report an appropriate error message to the console and terminate client]
     * </pre>
     */
    private static String parseInstruction(Queue<String> tokens,
            Statement body) {
        assert tokens != null : "Violation of: tokens is not null";
        assert body != null : "Violation of: body is not null";
        assert tokens.length() > 0 && tokens.front().equals("INSTRUCTION") : ""
                + "Violation of: <\"INSTRUCTION\"> is proper prefix of tokens";

        // make sure first line is instruction
        String instruction = tokens.dequeue();
        Reporter.assertElseFatalError(instruction.equals("INSTRUCTION"),
                "Expected: INSTRUCTION \n Found:" + instruction);

        // second token is name
        String name = tokens.dequeue();
        boolean isPrimitiveName = name.equals("move") || name.equals("skip")
                || name.equals("turnleft") || name.equals("turnright")
                || name.equals("infect");
        // have not operator to report error
        Reporter.assertElseFatalError(!isPrimitiveName,
                "Name must not be a primitive call");

        // third token is IS
        String is = tokens.dequeue();
        Reporter.assertElseFatalError(is.equals("IS"),
                "Expected: IS \n Found:" + is);

        // parse instructions
        body.parseBlock(tokens);

        // second to last token is END
        String end = tokens.dequeue();
        Reporter.assertElseFatalError(end.equals("END"),
                "Expected: END \n Found: " + end);

        // last token is name
        String name2 = tokens.dequeue();
        Reporter.assertElseFatalError(name2.equals(name),
                "Instuction name at start must match end");
        return name;
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Program1Parse1() {
        super();
    }

    /*
     * Public methods ---------------------------------------------------------
     */

    @Override
    public void parse(SimpleReader in) {
        assert in != null : "Violation of: in is not null";
        assert in.isOpen() : "Violation of: in.is_open";
        Queue<String> tokens = Tokenizer.tokens(in);
        this.parse(tokens);
    }

    @Override
    public void parse(Queue<String> tokens) {
        assert tokens != null : "Violation of: tokens is not null";
        assert tokens.length() > 0 : ""
                + "Violation of: Tokenizer.END_OF_INPUT is a suffix of tokens";

        // create new statement and map that we'll be using to help parse
        Statement newStatement = this.newBody();
        Map<String, Statement> newMap = this.newContext();

        this.swapBody(newStatement);
        this.swapContext(newMap);

        // make sure first line is program
        String program = tokens.dequeue();
        Reporter.assertElseFatalError(program.equals("PROGRAM"),
                "Expected: PROGRAM \n Found:" + program);

        // name of program
        String name = tokens.dequeue();

        // third token is IS
        String is = tokens.dequeue();
        Reporter.assertElseFatalError(is.equals("IS"),
                "Expected: IS \n Found:" + is);

        // need to determine if next token is instruction or begin

        while (tokens.front().equals("INSTRUCTION")) {
            Statement s = this.newBody();
            String instructionName = parseInstruction(tokens, s);
            Reporter.assertElseFatalError(!newMap.hasKey(instructionName),
                    "Can't have duplicate instruction names");
            newMap.add(instructionName, s);

        }

        // Begin
        String begin = tokens.dequeue();
        Reporter.assertElseFatalError(begin.equals("BEGIN"),
                "Expected: BEGIN \n Found: " + begin);

        Statement s = this.newBody();
        s.parseBlock(tokens);

        // second to last token is END
        String end = tokens.dequeue();
        Reporter.assertElseFatalError(end.equals("END"),
                "Expected: END \n Found: " + end);

        // last token is name
        String name2 = tokens.dequeue();
        Reporter.assertElseFatalError(name2.equals(name),
                "Program name at start must match end");

        // check if last token is END OF INPUT
        Reporter.assertElseFatalError(
                tokens.front().equals("### END OF INPUT ###"),
                "Expected: END-OF-INPUT expected \n Found: " + tokens.front());

        // put name, body of parsed statement, and map of instructions back into this
        this.setName(name);
        this.swapBody(s);
        this.swapContext(newMap);
    }

    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        out.print("Enter valid BL program file name: ");
        String fileName = in.nextLine();
        /*
         * Parse input file
         */
        out.println("*** Parsing input file ***");
        Program p = new Program1Parse1();
        SimpleReader file = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(file);
        file.close();
        p.parse(tokens);
        /*
         * Pretty print the program
         */
        out.println("*** Pretty print of parsed program ***");
        p.prettyPrint(out);

        in.close();
        out.close();
    }

}
