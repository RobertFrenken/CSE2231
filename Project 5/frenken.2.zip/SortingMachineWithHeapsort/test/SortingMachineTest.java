import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Robert Frenken
 * @author Bennett Palmer
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    // will need to test insertion mode and extraction mode if it can be called in both
    // methods that can be called in both: isInInsertionMode, order, and size

    // constructor (1 test)
    // add - empty, non empty, large (3 tests, one provided)
    // changeToExtractionMode - empty, large, small (3, cannot be empty)
    // removeFirst- to empty and to non empty, and large (3 tests)
    // isInInsertionMode - true and false,  is in insertion (true) and
    // is in extraction (false), for both empty and non empty (4 tests)
    // order - insertion and extraction, empty and non empty (4 tests)
    // size - zero and non zero, insertion and extraction (4 tests)
    // total: 22 (including constructor test)

    // 1
    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    // 2
    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        // call method under test
        m.add("green");
        assertEquals(mExpected, m);
    }

    // 3
    @Test
    public final void testAddNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue");
        // call method under test
        m.add("blue");
        assertEquals(mExpected, m);
    }

    // 4
    @Test
    public final void testChangeToExtractionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        mExpected.changeToExtractionMode();
        // call method under test
        m.changeToExtractionMode();
        assertEquals(mExpected, m);
    }

    // 5
    @Test
    public final void testRemoveFirstToEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        // call method under test
        m.removeFirst();
        assertEquals(mExpected, m);
    }

    // 6
    @Test
    public final void testRemoveFirstToNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green", "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green");
        // call method under test
        m.removeFirst();
        assertEquals(mExpected, m);
    }

    // 7
    @Test
    public final void testIsInInsertionModeTrueNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "green",
                "blue");

        // call method under test
        boolean insertionMode = m.isInInsertionMode();
        assertEquals(true, insertionMode);
    }

    // 8
    @Test
    public final void testIsInInsertionModeTrueEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);

        // call method under test
        boolean insertionMode = m.isInInsertionMode();
        assertEquals(true, insertionMode);
    }

    // 9
    @Test
    public final void testIsInInsertionModeFalseNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green", "blue");

        // call method under test
        boolean insertionMode = m.isInInsertionMode();
        assertEquals(false, insertionMode);
    }

    // 10
    @Test
    public final void testIsInInsertionModeFalseEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);

        // call method under test
        boolean insertionMode = m.isInInsertionMode();
        assertEquals(false, insertionMode);
    }

    // 11
    @Test
    public final void testOrderInsertionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        Comparator<String> orderExpected = mExpected.order();

        // call method under test
        Comparator<String> order = m.order();
        assertEquals(orderExpected, order);
    }

    // 12
    @Test
    public final void testOrderInsertionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "green",
                "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue");
        Comparator<String> orderExpected = mExpected.order();

        // call method under test
        Comparator<String> order = m.order();
        assertEquals(orderExpected, order);
    }

    // 13
    @Test
    public final void testOrderExtractionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green", "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green", "blue");
        Comparator<String> orderExpected = mExpected.order();

        // call method under test
        Comparator<String> order = m.order();
        assertEquals(orderExpected, order);
    }

    // 14
    @Test
    public final void testOrderExtractionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        Comparator<String> orderExpected = mExpected.order();

        // call method under test
        Comparator<String> order = m.order();
        assertEquals(orderExpected, order);
    }

    // 15
    @Test
    public final void testSizeExtractionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        int sizeExpected = mExpected.size();

        // call method under test
        int size = m.size();
        assertEquals(sizeExpected, size);
    }

    // 16
    @Test
    public final void testSizeExtractionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green", "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green", "blue");
        int sizeExpected = mExpected.size();

        // call method under test
        int size = m.size();
        assertEquals(sizeExpected, size);
    }

    // 17
    @Test
    public final void testSizeInsertionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "green",
                "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green", "blue");
        int sizeExpected = mExpected.size();

        // call method under test
        int size = m.size();
        assertEquals(sizeExpected, size);
    }

    // 18
    @Test
    public final void testSizeInsertionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        int sizeExpected = mExpected.size();

        // call method under test
        int size = m.size();
        assertEquals(sizeExpected, size);
    }

    // 19
    @Test
    public final void testRemoveFirstToLargerHeap() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "g",
                "f", "d", "e", "c", "b", "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "b", "c", "d", "e", "f", "g");
        // call method under test
        m.removeFirst();
        assertEquals(mExpected, m);
    }

    // 20
    @Test
    public final void testChangeToExtractionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        mExpected.changeToExtractionMode();
        // call method under test
        m.changeToExtractionMode();
        assertEquals(mExpected, m);
    }

    // 21
    @Test
    public final void testChangeToExtractionModeLargerHeap() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "g",
                "f", "d", "e", "c", "b", "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "b", "c", "d", "e", "f", "g", "a");
        mExpected.changeToExtractionMode();
        // call method under test
        m.changeToExtractionMode();
        assertEquals(mExpected, m);
    }

    // 22
    @Test
    public final void testAddLargerHeap() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "g",
                "f", "d", "e", "c", "b");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c", "d", "e", "f", "g");
        // call method under test
        m.add("a");
        assertEquals(mExpected, m);
    }
}
